package gr.hua.dit.ds.Project2.repository;


import gr.hua.dit.ds.Project2.Entity.Lessor;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

@RepositoryRestResource(path="lessor")
public interface LessorRepository extends JpaRepository<Lessor, Integer> {
}
