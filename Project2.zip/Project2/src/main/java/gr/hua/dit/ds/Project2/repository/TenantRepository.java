package gr.hua.dit.ds.Project2.repository;

import gr.hua.dit.ds.Project2.Entity.Tenant;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

@RepositoryRestResource(path="tenant")
public interface TenantRepository extends JpaRepository<Tenant, Integer> {
}
