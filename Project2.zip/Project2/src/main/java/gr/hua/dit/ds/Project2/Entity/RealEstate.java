package gr.hua.dit.ds.Project2.Entity;

import com.fasterxml.jackson.annotation.JsonBackReference;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import java.util.List;

@Entity
@Table(name="RealEstate")
public class RealEstate {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "id")
    private int id;

    @Column(name = "Num")
    @NotBlank(message="Num")
    private String Num;


    @Column(name = "City")
    @Size(max = 30, message = "Name should not be greater than 30 characters")
    private String city;

    @Column(name = "Worth")
    @NotBlank(message="Worth")
    private int worth;

    @Column(name = "Reason")
    @NotBlank(message="Reason buying this real estate")
    private String reason;

    @Column(name = "period")
    @NotBlank(message="How many months?")
    private int period;

    @Column(name = "area")
    @NotBlank(message="area")
    private String area;

    @Column(name = "DEH")
    @NotBlank(message="Number of electric provision")
    private String DEH;

    @ManyToOne(cascade= {CascadeType.PERSIST, CascadeType.MERGE,
            CascadeType.DETACH, CascadeType.REFRESH})
    @JoinColumn(name="lessor_afm")
    @JsonBackReference
    private Lessor lessor;


    @ManyToMany(fetch=FetchType.LAZY,
            cascade= {CascadeType.PERSIST, CascadeType.MERGE,
                    CascadeType.DETACH, CascadeType.REFRESH})
    @JoinTable(
            name="realEstate_tenant",
            joinColumns=@JoinColumn(name="realEstate_id"),
            inverseJoinColumns=@JoinColumn(name="tenant_id"))
    private List<Tenant> tenant;

    @OneToOne(cascade=CascadeType.ALL)
    @JoinColumn(name="Contract")
    @JsonBackReference
    private Contract contract_id;

    public RealEstate() {
    }

    public RealEstate(String num, String city, int worth, String reason, int period, String area, String DEH) {
        Num = num;
        this.city = city;
        this.worth = worth;
        this.reason = reason;
        this.period = period;
        this.area = area;
        this.DEH = DEH;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNum() {
        return Num;
    }

    public void setNum(String num) {
        Num = num;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public int getWorth() {
        return worth;
    }

    public void setWorth(int worth) {
        this.worth = worth;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public int getPeriod() {
        return period;
    }

    public void setPeriod(int period) {
        this.period = period;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public String getDEH() {
        return DEH;
    }

    public void setDEH(String DEH) {
        this.DEH = DEH;
    }

    public Lessor getLessor() {
        return lessor;
    }

    public void setLessor(Lessor lessor) {
        this.lessor = lessor;
    }

    public List<Tenant> getTenant() {
        return tenant;
    }

    public void setTenant(List<Tenant> tenant) {
        this.tenant = tenant;
    }

    public Contract getContract_id() {
        return contract_id;
    }

    public void setContract_id(Contract contract_id) {
        this.contract_id = contract_id;
    }

    @Override
    public String toString() {
        return "RealEstate{" +
                "id=" + id +
                ", Num='" + Num + '\'' +
                ", city='" + city + '\'' +
                ", worth='" + worth + '\'' +
                ", reason='" + reason + '\'' +
                ", period=" + period +
                ", area='" + area + '\'' +
                ", DEH='" + DEH + '\'' +
                ", lessor=" + lessor +
                ", tenant=" + tenant +
                ", contract_id=" + contract_id +
                '}';
    }
}
