package gr.hua.dit.ds.Project2.DAO;

public class RealEstateDAOImpl {
}
