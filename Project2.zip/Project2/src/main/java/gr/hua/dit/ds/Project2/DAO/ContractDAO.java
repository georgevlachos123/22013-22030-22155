package gr.hua.dit.ds.Project2.DAO;

import gr.hua.dit.ds.Project2.Entity.Contract;

import java.util.List;

public interface ContractDAO {

    public List<Contract> findAll();

    public void save(Contract contract);

    public Contract findById(int id);

    public Contract findByLessor(int afm);

    public void delete(int id);

    public Contract Confirmation(boolean reply);

    public Contract Update(int id,int price,int period,String terms);


}
