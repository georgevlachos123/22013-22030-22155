package gr.hua.dit.ds.Project2.Controller;

public class TenantController {
}
