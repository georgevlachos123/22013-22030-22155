package gr.hua.dit.ds.Project2.Entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import javax.persistence.*;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.util.List;

@Entity
@Table(name="lessor")
public class Lessor implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "AFM")
    private int afm;

    @Column(name = "First_name")
    @NotBlank(message="Please enter the first name")
    @Size(max = 30, message = "Name should not be greater than 30 characters")
    private String firstName;

    @Column(name = "Last_name")
    @NotBlank(message="Please enter the last name")
    @Size(max = 30, message = "Name should not be greater than 30 characters")
    private String lastName;

    @Column(name="email", unique = true)
    @Email(message = "Please enter your email")
    @Size(max = 50)
    private String email;

    @OneToMany(mappedBy="lessor",
            cascade= {CascadeType.PERSIST, CascadeType.MERGE,
                    CascadeType.DETACH, CascadeType.REFRESH})
    @JoinColumn(name="realEstate_id")
    @JsonManagedReference
    private List<RealEstate> realEstate_id;

    @OneToMany(cascade= {CascadeType.PERSIST, CascadeType.MERGE,
            CascadeType.DETACH, CascadeType.REFRESH})
    @JoinColumn(name="Contract_id")
    @JsonBackReference
    private List<Contract> contract_id;

    public Lessor() {
    }

    public Lessor(String firstName, String lastName, String email) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
    }

    public int getAfm() {
        return afm;
    }

    public void setAfm(int afm) {
        this.afm = afm;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public List<RealEstate> getRealEstate_id() {
        return realEstate_id;
    }

    public void setRealEstate_id(List<RealEstate> realEstate_id) {
        this.realEstate_id = realEstate_id;
    }

    public List<Contract> getContract_id() {
        return contract_id;
    }

    public void setContract_id(List<Contract> contract_id) {
        this.contract_id = contract_id;
    }

    @Override
    public String toString() {
        return "Lessor{" +
                "afm=" + afm +
                ", firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", email='" + email + '\'' +
                ", realEstate_id=" + realEstate_id +
                ", contract_id=" + contract_id +
                '}';
    }
}
