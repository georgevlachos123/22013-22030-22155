package gr.hua.dit.ds.Project2.Entity;


import com.fasterxml.jackson.annotation.JsonBackReference;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;

@Entity
@Table(name="Contract")
public class Contract {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "id")
    private int id;

    @ManyToOne(cascade= {CascadeType.PERSIST, CascadeType.MERGE,
            CascadeType.DETACH, CascadeType.REFRESH})
    @JoinColumn(name="lessor_firstName")
    @JsonBackReference
    private Lessor lessor_firstName;

    @ManyToOne(cascade= {CascadeType.PERSIST, CascadeType.MERGE,
            CascadeType.DETACH, CascadeType.REFRESH})
    @JoinColumn(name="lessor_afm")
    @JsonBackReference
    private Lessor lessor_afm;

    @ManyToMany(cascade= {CascadeType.PERSIST, CascadeType.MERGE,
            CascadeType.DETACH, CascadeType.REFRESH})
    @JoinColumn(name="tenant_firstName")
    @JsonBackReference
    private Tenant tenant_firstName;

    @ManyToMany(cascade= {CascadeType.PERSIST, CascadeType.MERGE,
            CascadeType.DETACH, CascadeType.REFRESH})
    @JoinColumn(name="tenant_afm")
    @JsonBackReference
    private Tenant tenant_afm;

    @OneToOne(cascade=CascadeType.ALL)
    @JoinColumn(name="realEstate")
    @JsonBackReference
    private RealEstate realEstate;

    @Column(name="terms")
    @NotBlank(message="Terms for the Real Estate")
    private String terms;

    @ManyToOne(cascade= {CascadeType.PERSIST, CascadeType.MERGE,
            CascadeType.DETACH, CascadeType.REFRESH})
    @JoinColumn(name="lessor_email")
    @JsonBackReference
    private Lessor lessor_email;

    @OneToOne(cascade=CascadeType.ALL)
    @JoinColumn(name="worth")
    @JsonBackReference
    private RealEstate worth;

    @OneToOne(cascade=CascadeType.ALL)
    @JoinColumn(name="period")
    @JsonBackReference
    private RealEstate  period;

    public Contract() {
    }

    public Contract(Lessor lessor_firstName, Tenant tenant_firstName, String terms, Lessor lessor_email, RealEstate worth, RealEstate period) {
        this.lessor_firstName = lessor_firstName;
        this.tenant_firstName = tenant_firstName;
        this.terms = terms;
        this.lessor_email = lessor_email;
        this.worth = worth;
        this.period = period;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Lessor getLessor_firstName() {
        return lessor_firstName;
    }

    public void setLessor_firstName(Lessor lessor_firstName) {
        this.lessor_firstName = lessor_firstName;
    }

    public Lessor getLessor_afm() {
        return lessor_afm;
    }

    public void setLessor_afm(Lessor lessor_afm) {
        this.lessor_afm = lessor_afm;
    }

    public Tenant getTenant_firstName() {
        return tenant_firstName;
    }

    public void setTenant_firstName(Tenant tenant_firstName) {
        this.tenant_firstName = tenant_firstName;
    }

    public Tenant getTenant_afm() {
        return tenant_afm;
    }

    public void setTenant_afm(Tenant tenant_afm) {
        this.tenant_afm = tenant_afm;
    }

    public RealEstate getRealEstate() {
        return realEstate;
    }

    public void setRealEstate(RealEstate realEstate) {
        this.realEstate = realEstate;
    }

    public String getTerms() {
        return terms;
    }

    public void setTerms(String terms) {
        this.terms = terms;
    }

    public Lessor getLessor_email() {
        return lessor_email;
    }

    public void setLessor_email(Lessor lessor_email) {
        this.lessor_email = lessor_email;
    }

    public RealEstate getWorth() {
        return worth;
    }

    public void setWorth(RealEstate worth) {
        this.worth = worth;
    }

    public RealEstate getPeriod() {
        return period;
    }

    public void setPeriod(RealEstate period) {
        this.period = period;
    }

    @Override
    public String toString() {
        return "Contract{" +
                "id=" + id +
                ", lessor_firstName=" + lessor_firstName +
                ", lessor_afm=" + lessor_afm +
                ", tenant_firstName=" + tenant_firstName +
                ", tenant_afm=" + tenant_afm +
                ", realEstate=" + realEstate +
                ", terms='" + terms + '\'' +
                ", lessor_email=" + lessor_email +
                ", worth=" + worth +
                ", period=" + period +
                '}';
    }
}
