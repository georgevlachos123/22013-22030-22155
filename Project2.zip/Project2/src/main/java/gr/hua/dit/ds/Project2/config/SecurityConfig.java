package gr.hua.dit.ds.Project2.config;

public class SecurityConfig {
}
