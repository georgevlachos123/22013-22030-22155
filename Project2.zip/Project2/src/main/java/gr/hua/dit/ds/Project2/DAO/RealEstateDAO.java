package gr.hua.dit.ds.Project2.DAO;

import gr.hua.dit.ds.Project2.Entity.RealEstate;
import java.util.List;

public interface RealEstateDAO {

    public List<RealEstate> findAll();

    public void save(RealEstate realEstate);

    public RealEstate findById(int id);

    public RealEstate delete(int id);

}
