package gr.hua.dit.ds.Project2.Entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import javax.persistence.*;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import java.util.List;

@Entity
@Table(name="tenant")
public class Tenant {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "AFM")
    private int afm;

    @Column(name = "First_name")
    @NotBlank(message="Please enter the first name")
    @Size(max = 30, message = "Name should not be greater than 30 characters")
    private String firstName;


    @Column(name = "Last_name")
    @NotBlank(message="Please enter the last name")
    @Size(max = 30, message = "Name should not be greater than 30 characters")
    private String lastName;

    @Column(name="email", unique = true)
    @Email(message = "Please enter your email")
    @Size(max = 50)
    private String email;


    @ManyToMany(fetch=FetchType.LAZY,
            cascade= {CascadeType.PERSIST, CascadeType.MERGE,
                    CascadeType.DETACH, CascadeType.REFRESH})
    @JoinTable(
            name="realEstate_tenant",
            joinColumns=@JoinColumn(name="tenant_id"),
            inverseJoinColumns=@JoinColumn(name="realEstate_id"))
    private List<RealEstate> realEstate;

    @ManyToMany(cascade= {CascadeType.PERSIST, CascadeType.MERGE,
            CascadeType.DETACH, CascadeType.REFRESH})
    @JoinTable(
            name="contract_tenant",
            joinColumns=@JoinColumn(name="tenant_id"),
            inverseJoinColumns=@JoinColumn(name="contract_id"))
    @JsonBackReference
    private List<Contract> contract;

    public Tenant() {
    }

    public Tenant(String firstName, String lastName, String email) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
    }

    public int getAfm() {
        return afm;
    }

    public void setAfm(int afm) {
        this.afm = afm;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public List<RealEstate> getRealEstate() {
        return realEstate;
    }

    public void setRealEstate(List<RealEstate> realEstate) {
        this.realEstate = realEstate;
    }

    public List<Contract> getContract() {
        return contract;
    }

    public void setContract(List<Contract> contract) {
        this.contract = contract;
    }

    @Override
    public String toString() {
        return "Tenant{" +
                "afm=" + afm +
                ", firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", email='" + email + '\'' +
                ", realEstate=" + realEstate +
                ", contract=" + contract +
                '}';
    }
}
